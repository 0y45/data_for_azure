
testfinal - v2 2022-02-09 11:46pm
==============================

This dataset was exported via roboflow.ai on February 9, 2022 at 8:47 PM GMT

It includes 2268 images.
Testfinal are annotated in Pascal VOC format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


